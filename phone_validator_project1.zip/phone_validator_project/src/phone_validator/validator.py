# src/phone_validator/validator.py
"""Валидация телефонов."""

import re


_PHONE_RE = re.compile(
    r"^"
    r"(?P<country>\+7|8)"      # код страны или выхода (+7 или 8)
    r"[\s\-]?"
    r"(?P<code>\(?\d{3}\)?)"   # код оператора/региона (3 цифры, со скобками или без)
    r"[\s\-]?"
    r"(?P<part1>\d{3})"        # первые 3 цифры абонентского номера
    r"[\s\-]?"
    r"(?P<part2>\d{2})"        # следующие 2 цифры
    r"[\s\-]?"
    r"(?P<part3>\d{2})"        # последние 2 цифры
    r"\Z"
)




def is_valid_phone(phone: str) -> bool:
    """Проверяет, является ли строка корректным номером телефона.

    Args:
        phone: строка для проверки.

    Returns:
        True, если номер похож на корректный, иначе False.

    Examples:
        >>> is_valid_phone("+79991234567")
        True
        >>> is_valid_phone("not-a-phone")
        False
    """
    if not isinstance(phone, str):
        return False
    if not phone:
        return False
    return _PHONE_RE.match(phone) is not None
